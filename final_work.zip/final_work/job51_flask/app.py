from flask import Flask,render_template
import sqlite3
app = Flask(__name__)


@app.route('/')
def index():
    return render_template("home.html")

@app.route("/home")
def home():
    # return render_template("index.html")
    return index()

@app.route('/worklist')
def worklist():
    datalist=[]
    conn=sqlite3.connect("job51.db")
    cur=conn.cursor()
    sql="select * from  job51"
    data=cur.execute(sql)
    for item in data:
        datalist.append(item)
    cur.close()
    conn.close()
    return render_template("worklist.html",worklists=datalist)     #页面接参数的方式，直接在后面加逗号

@app.route('/salary')
def salary():
    salary=[]
    num=[]
    con=sqlite3.connect("job51.db")
    cur=con.cursor()
    sql="select month_salary,count(month_salary) from job51 group by month_salary"
    data=cur.execute(sql)

    for item in data:
        salary.append(item[0])
        num.append(item[1])
    #print(salary[0])
    #print(len(num))
    cur.close()
    con.close()
    # salary=['apple','lemon','orange','peach','banana','grape','mango']
    # num=[300,400,350,200,109,120,470]
    return render_template("salary.html",salary=salary,num=num)

@app.route('/wordcloud')
def word():
    return render_template("wordcloud.html")

@app.route('/team')
def team():
    return render_template("team.html")


if __name__ == '__main__':
    app.run()

