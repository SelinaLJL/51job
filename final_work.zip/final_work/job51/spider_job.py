#-*-coding=utf-8 -*-
#@Time:2021/3/31 9:06
#@Author:刘君兰
#@File:spider_job.py
#@software:PyCharm


#爬取数据 数据保存 搭建框架 制作图表


import re                          #正则表达式，进行文字匹配
from bs4 import BeautifulSoup      #网页解析，获取数据
import urllib.request,urllib.error   #指定URL,获取网页数据
import xlwt                         #进行excel操作
import sqlite3

def main():
    #爬取网页信息
    #baseurl="https://search.51job.com/list/030200,000000,0000,00,9,99,python,2,1.html"
    baseurl = "https://search.51job.com/list/030200,000000,0000,00,9,99,python,2,"
    datalist=getData(baseurl)

    #保存在excel中
    #savapath="job51.xls"
    #saveData(savapath,datalist);



    #保存在数据库中
    dbpath="job51.db"
    saveData2DB(datalist,dbpath)


findjobname=re.compile(r'"job_name":"(.*?)"')
findcompanyname=re.compile(r'"company_name":"(.*?)"')
findcomplink=re.compile(r'"company_href":"(.*?)"')
findcompInf=re.compile(r'"companytype_text":"(.*?)"')
findsalary=re.compile(r'"providesalary_text":"(.*?)"')
findworkplace=re.compile(r'"workarea_text":"(.*?)"')


findwel=re.compile(r'"jobwelf":"(.*?)"')
findisIntern=re.compile(r'"isIntern":"(.*?)"')

def getData(baseurl):
    datalist=[]
    for i in range(1,21):
        url=baseurl+str(i)+".html?lang=c&postchannel=0000&workyear=99&cotype=99&degreefrom=99&jobterm=99&companysize=99&ord_field=0&dibiaoid=0&line=&welfare="
        html=askURL(url)
        #逐一解析数据
        #用html解析器，把文档存放在内存中
        soup=BeautifulSoup(html,"html.parser")        #利用靓汤的网页解析工具
        for i,item in enumerate(soup.find_all('script', type='text/javascript')):  #提取出含有我们要的信息的对应标签
            data=[];

            data2=[]
            if i==2: #只有第三个标签才有我们要的信息
                item=str(item);

                #print(item)

                #找到工作名称
                jobname=re.findall(findjobname,item)
                #print(len(jobname))
                data.append(jobname)

                #招聘公司名称
                companyname=re.findall(findcompanyname,item)
                #print(len(companyname))
                data.append(companyname)


                #公司性质
                compInf=re.findall(findcompInf,item)
                #print(len(compInf))
                data.append(compInf)

                #招聘公司链接
                complink=re.findall(findcomplink,item)
                #print(len(complink))
                data.append(complink)

                #工资薪酬
                salary=re.findall(findsalary,item)

                #print(salary)
                data.append(salary)

                #工作地点
                workplace=re.findall(findworkplace,item)
                #print(len(workplace))
                data.append(workplace)

                #是否是实习
                isIntern=re.findall(findisIntern,item)
                for i in range(len(isIntern)):
                    if isIntern[i]=="0":isIntern[i]="否"
                    else:isIntern[i]="是"
                #print(isIntern)
                data.append(isIntern)

                #福利待遇
                wel=re.findall(findwel,item)
                #print(len(wel))
                data.append(wel)
                #print(data)


                #因为爬取是按照每个类别来的，需要把一个工作的不同类别信息合在一起

                for i in range(len(data[0])):      #len(data[0])=50
                    data1=[]
                    for j in range(len(data)):     #len(data)=8
                        #print(data[4][i])
                        k=i
                        if not data[4][k]:
                            data[4][k]="空"

                        data1.append(data[j][i])
                    #print(data1)
                    data2.append(data1)          #得到每一页网页的50个岗位，每个岗位有8个属性
                datalist+=data2                   #将20页的网页加起来，得到1000个岗位

                #print("data2:行=%d,列=%d"%(len(data2),len(data2[0])))
               #print(data2)

    #print(datalist)
    #print("datalist:行=%d,列=%d"%(len(datalist),len(datalist[0])))
    return datalist

def askURL(url):
    head={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36"}
    #建立请求
    request=urllib.request.Request(headers=head,url=url)
    try:
        #发送请求
        response=urllib.request.urlopen(request)
        #将爬取下来地信息保存到html
        html=response.read().decode("gbk");
        #html=response.read()


        #print(html)
    except urllib.error.URLError as e:
        if hasattr(e, "code"):
            print(e, code);
        if hasattr(e, "reason"):
            print(e.reason);
    return html


#保存数据在excel中
def saveData(savepath,datalist):
    print("save...")
    book=xlwt.Workbook(encoding="utf-8",style_compression=0)
    sheet=book.add_sheet("job51",cell_overwrite_ok=True);
    #jobname,companyname,compInf,complink,salary,workplace,IsIntern,wel)
    firstcol=("职位名称","公司名字","公司性质","公司链接","月薪","工作地点","是否是实习","待遇")
    for i in range(8):
        sheet.write(0,i,firstcol[i])
    for i in range(0,1000):
        #print("第%d条"%(i+1))
        data=datalist[i]
        for j in range(8):
            sheet.write(i+1,j,data[j])
    book.save(savepath)


#保存数据在数据库中
def saveData2DB(datalist,dbpath):
    init_db(dbpath)
    conn=sqlite3.connect(dbpath)
    cur=conn.cursor()
    #print(datalist)
    for data in datalist:
        for index in range(len(data)):
            data[index]='"'+data[index]+'"'
        sql = '''
                insert into job51(
                jobname,companyname,compInf,complink,month_salary,workplace,IsIntern,wel)         
                values(%s)''' % (",".join(data))
        #print(sql)
        cur.execute(sql)
        conn.commit()
    cur.close()
    conn.close()




def init_db(dbpath):
    sql='''
        create table job51
    (
    id integer primary key autoincrement,
    jobname text,
    companyname  text,
    compInf text,
    complink text,
    month_salary text ,
    workplace text,
    IsIntern text ,
    wel text
    );
    
    '''
    conn=sqlite3.connect(dbpath)
    cur=conn.cursor()
    cur.execute(sql)
    conn.commit()
    cur.close()
    conn.close()

if __name__ == "__main__":  #当程序执行时
    #当这个文件作为模块导入其他文件时，不会被运行。

    #调用函数
    main();
    print("爬取完毕！")